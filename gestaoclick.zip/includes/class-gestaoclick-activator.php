<?php

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Gestaoclick
 * @subpackage Gestaoclick/includes
 * @author     Oswaldo Cavalcante <contato@oswaldocavalcante.com>
 */

class Gestaoclick_Activator 
{
	public static function activate()
	{
		// Registra o hook de ativação ANTES de instalar as dependências
		register_activation_hook(__FILE__, function () 
		{
			flush_rewrite_rules();
		});

		self::create_quote_page();
		self::create_quote_checkout_page();

		if (!self::install_dependencies())
		{
			deactivate_plugins(plugin_basename(__FILE__));
			wp_die('Erro ao instalar as dependências do plugin. Verifique os logs do servidor para mais detalhes.', 'Plugin Activation Error', array('response' => 500, 'back_link' => true));
		}
	}

	private static function install_dependencies()
	{
		$plugin_path = GCW_ABSPATH;
		$composer_path = $plugin_path . 'composer.phar';

		// Verifica se o composer.phar existe, se não, tenta baixar
		if (!file_exists($composer_path))
		{
			$composer_url = 'https://getcomposer.org/composer.phar';
			$response = wp_remote_get($composer_url, array('timeout' => 300, 'stream' => true, 'filename' => $composer_path));

			if (is_wp_error($response))
			{
				error_log('Erro ao baixar composer.phar: ' . $response->get_error_message());
				return false;
			}

			if (wp_remote_retrieve_response_code($response) !== 200)
			{
				error_log('Erro ao baixar composer.phar: Código de resposta HTTP inválido: ' . wp_remote_retrieve_response_code($response));
				return false;
			}
		}

		// Verifica se as funções PHP necessárias estão habilitadas
		if (!function_exists('shell_exec'))
		{
			error_log('A função PHP shell_exec() não está habilitada.');
			return false;
		}

		// Verifica se o diretório do plugin tem permissões de escrita
		if (!is_writable($plugin_path))
		{
			error_log('O diretório do plugin não tem permissões de escrita.');
			return false;
		}

		// Define o PATH para incluir o diretório do executável do PHP
		$current_env_path = getenv('PATH');
		$env_path = $current_env_path . ':/usr/local/bin:/usr/bin:/bin:/Users/oswaldocavalcante/Library/Application Support/Local/lightning-services/php-8.2.23+0/bin/darwin-arm64/bin'; // Adicione outros diretórios conforme necessário
		putenv("PATH=$env_path");

		// Executa o composer install usando shell_exec()
		$command = "php " . escapeshellarg($composer_path) . " install --no-dev --optimize-autoloader --no-interaction --working-dir=" . escapeshellarg(dirname(plugin_dir_path(__FILE__)));
		$output = shell_exec($command . ' 2>&1'); // Redireciona stderr para stdout

		// Registra a saída completa do comando composer install
		if (!empty($output))
		{
			error_log('Saída do comando composer install: ' . $output);
		}
		else
		{
			error_log('O comando composer install não gerou nenhuma saída.');
			return false;
		}

		return true;
	}

	private static function create_quote_page()
	{
		// Verificar se a página já existe
		$page_title = 'Orçamento';
		$page_content = '[gestaoclick_orcamento]';
		$page_check = get_page_by_path('orcamento');

		// Se a página não existir, crie-a
		if (!isset($page_check->ID))
		{
			$page_id = wp_insert_post(array
			(
				'post_title'     => $page_title,
				'post_content'   => $page_content,
				'post_status'    => 'publish',
				'post_type'      => 'page',
				'post_author'    => 1,
				'comment_status' => 'closed',
				'ping_status'    => 'closed',
			));

			update_option('gcw_quote_page_id', $page_id);
			update_option('gcw_quote_page_url', get_permalink($page_id));
		} 
		else 
		{
			// Atualizar a opção com o ID da página existente
			update_option('gcw_quote_page_id', $page_check->ID);
			update_option('gcw_quote_page_url', get_permalink($page_check->ID));
		}
	}

	private static function create_quote_checkout_page()
	{
		// Verificar se a página já existe
		$page_title = 'Finalizar Orçamento';
		$page_content = '[gestaoclick_finalizar_orcamento]';
		$page_check = get_page_by_path('finalizar-orcamento');

		// Se a página não existir, crie-a
		if (!isset($page_check->ID)) 
		{
			$page_id = wp_insert_post(array
			(
				'post_title'     => $page_title,
				'post_content'   => $page_content,
				'post_status'    => 'publish',
				'post_type'      => 'page',
				'post_author'    => 1,
				'comment_status' => 'closed',
				'ping_status'    => 'closed',
			));

			update_option('gcw_quote_page_id', $page_id);
			update_option('gcw_quote_page_url', get_permalink($page_id));
		} 
		else 
		{
			// Atualizar a opção com o ID da página existente
			update_option('gcw_quote_page_id', $page_check->ID);
			update_option('gcw_quote_page_url', get_permalink($page_check->ID));
		}
	}
}
